package com.pamelagutierrez.recordatorios.model

sealed class ResultadoValidacion {
    data object Valido : ResultadoValidacion()
    data class Invalido(val motivo: String) : ResultadoValidacion()
}

fun validar(recordatorio: Recordatorio): ResultadoValidacion = when {
    recordatorio.titulo.isBlank() ->
        ResultadoValidacion.Invalido("El título no puede estar vacío")
    recordatorio.titulo.length > 60 ->
        ResultadoValidacion.Invalido("El título no puede superar los 60 caracteres")
    recordatorio.estado is EstadoRecordatorio.Pospuesto && recordatorio.estado.hasta.isBlank() ->
        ResultadoValidacion.Invalido("Un recordatorio pospuesto necesita una fecha")
    else -> ResultadoValidacion.Valido
}