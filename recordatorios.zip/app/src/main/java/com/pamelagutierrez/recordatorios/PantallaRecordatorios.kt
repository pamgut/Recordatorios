package com.pamelagutierrez.recordatorios.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pamelagutierrez.recordatorios.data.DatosSimulados
import com.pamelagutierrez.recordatorios.data.Filtro
import com.pamelagutierrez.recordatorios.model.EstadoRecordatorio
import com.pamelagutierrez.recordatorios.model.Recordatorio
import com.pamelagutierrez.recordatorios.ui.theme.RecordatoriosTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaRecordatorios(modifier: Modifier = Modifier) {
    var filtroActual by remember { mutableStateOf(Filtro.TODOS) }
    val recordatorios = remember(filtroActual) { DatosSimulados.filtrar(filtroActual) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Mis recordatorios", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Filtro.entries.forEach { filtro ->
                    FilterChip(
                        selected = filtro == filtroActual,
                        onClick = { filtroActual = filtro },
                        label = { Text(filtro.etiqueta) }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(recordatorios, key = { it.id }) { recordatorio ->
                    TarjetaRecordatorio(recordatorio)
                }
            }
        }
    }
}

@Composable
fun TarjetaRecordatorio(recordatorio: Recordatorio) {
    val colorCategoria = DatosSimulados.colorPorCategoria[recordatorio.categoria]
        ?.let { Color(it) } ?: Color.Gray

    val textoEstado = when (val estado = recordatorio.estado) {
        EstadoRecordatorio.Pendiente -> "Pendiente"
        is EstadoRecordatorio.Pospuesto -> "Pospuesto hasta ${estado.hasta}"
        EstadoRecordatorio.Completado -> "Completado"
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = recordatorio.titulo,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(colorCategoria, CircleShape)
                )
                Text(
                    text = "  ${recordatorio.categoria.nombre}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Text(
                text = "Prioridad: ${recordatorio.prioridad.etiqueta}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Estado: $textoEstado",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            recordatorio.fechaLimite?.let {
                Text("Vence: $it", style = MaterialTheme.typography.bodySmall)
            }
            recordatorio.ubicacion?.let {
                Text("Lugar: $it", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PantallaRecordatoriosPreview() {
    RecordatoriosTheme { PantallaRecordatorios() }
}