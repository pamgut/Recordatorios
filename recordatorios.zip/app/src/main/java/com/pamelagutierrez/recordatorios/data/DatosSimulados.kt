package com.pamelagutierrez.recordatorios.data

import com.pamelagutierrez.recordatorios.model.Categoria
import com.pamelagutierrez.recordatorios.model.EstadoRecordatorio
import com.pamelagutierrez.recordatorios.model.Prioridad
import com.pamelagutierrez.recordatorios.model.Recordatorio
import com.pamelagutierrez.recordatorios.model.ResultadoValidacion
import com.pamelagutierrez.recordatorios.model.validar

enum class Filtro(val etiqueta: String) {
    TODOS("Todos"),
    PENDIENTES("Pendientes"),
    COMPLETADOS("Completados"),
    PRIORIDAD_ALTA("Prioridad alta")
}

object DatosSimulados {

    private val trabajo = Categoria(1, "Trabajo")
    private val hogar = Categoria(2, "Hogar")
    private val estudio = Categoria(3, "Estudio")
    private val salud = Categoria(4, "Salud")

    // SET: la lista trae "Trabajo" repetida a propósito; el Set la deja una sola vez.
    val categorias: Set<Categoria> = listOf(trabajo, hogar, estudio, salud, trabajo).toSet()

    // MAP: cada categoría tiene asociado un color.
    val colorPorCategoria: Map<Categoria, Long> = mapOf(
        trabajo to 0xFF1E88E5,
        hogar to 0xFF43A047,
        estudio to 0xFF8E24AA,
        salud to 0xFFE53935
    )

    // LIST: los recordatorios de ejemplo.
    private val todos: List<Recordatorio> = listOf(
        Recordatorio(
            1, "Entregar informe mensual", trabajo, Prioridad.Alta,
            descripcion = "Enviar el PDF al área de gestión", fechaLimite = "05/11/2026"
        ),
        Recordatorio(2, "Reunión de equipo", trabajo, Prioridad.Media, ubicacion = "Sala 3"),
        Recordatorio(3, "Pagar cuenta de la luz", hogar, Prioridad.Alta, fechaLimite = "08/11/2026"),
        Recordatorio(
            4, "Comprar útiles de limpieza", hogar, Prioridad.Baja,
            estado = EstadoRecordatorio.Completado
        ),
        Recordatorio(
            5, "Estudiar para el examen de Kotlin", estudio, Prioridad.Alta,
            estado = EstadoRecordatorio.Pospuesto("10/11/2026")
        ),
        Recordatorio(6, "Leer capítulo de Compose", estudio, Prioridad.Media),
        Recordatorio(
            7, "Control médico anual", salud, Prioridad.Media,
            descripcion = "Llevar exámenes anteriores", ubicacion = "Clínica Central"
        ),
        Recordatorio(
            8, "Tomar vitaminas", salud, Prioridad.Baja,
            estado = EstadoRecordatorio.Completado
        )
    ).filter { validar(it) is ResultadoValidacion.Valido }

    fun filtrar(filtro: Filtro): List<Recordatorio> {
        val seleccion = when (filtro) {
            Filtro.TODOS -> todos
            Filtro.PENDIENTES -> todos.filter { it.estado !is EstadoRecordatorio.Completado }
            Filtro.COMPLETADOS -> todos.filter { it.estado is EstadoRecordatorio.Completado }
            Filtro.PRIORIDAD_ALTA -> todos.filter { it.prioridad == Prioridad.Alta }
        }
        return seleccion.sortedByDescending { it.prioridad.peso }
    }
}