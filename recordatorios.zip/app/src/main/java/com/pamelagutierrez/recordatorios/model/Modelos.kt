package com.pamelagutierrez.recordatorios.model

data class Categoria(
    val id: Int,
    val nombre: String
)

sealed class Prioridad(val etiqueta: String, val peso: Int) {
    data object Alta : Prioridad("Alta", 3)
    data object Media : Prioridad("Media", 2)
    data object Baja : Prioridad("Baja", 1)
}

sealed class EstadoRecordatorio {
    data object Pendiente : EstadoRecordatorio()
    data class Pospuesto(val hasta: String) : EstadoRecordatorio()
    data object Completado : EstadoRecordatorio()
}

data class Recordatorio(
    val id: Int,
    val titulo: String,
    val categoria: Categoria,
    val prioridad: Prioridad,
    val estado: EstadoRecordatorio = EstadoRecordatorio.Pendiente,
    val descripcion: String? = null,
    val fechaLimite: String? = null,
    val ubicacion: String? = null
)